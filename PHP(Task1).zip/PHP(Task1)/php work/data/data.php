<?php
 
 $products = [
    ['name' => 'Product1', 'img' => '/img/product-1.jpg', 'price' => 100,'discount'=>0.1,'rating'=>0,'rating_count'=>100,'is_featured'=>true,'is_recent'=>false],
    ['name' => 'Product2', 'img' => '/img/product-2.jpg', 'price' => 110,'discount'=>0.125,'rating'=>1,'rating_count'=>90,'is_featured'=>true,'is_recent'=>false],
    ['name' => 'Product3', 'img' => '/img/product-3.jpg', 'price' => 120,'discount'=>0.2,'rating'=>1.5,'rating_count'=>95,'is_featured'=>true,'is_recent'=>false],
    ['name' => 'Product4', 'img' => '/img/product-4.jpg', 'price' => 130,'discount'=>0.1,'rating'=>4.5,'rating_count'=>100,'is_featured'=>true,'is_recent'=>false],
    ['name' => 'Product5', 'img' => '/img/product-5.jpg', 'price' => 140,'discount'=>0.1,'rating'=>3.5,'rating_count'=>97,'is_featured'=>false,'is_recent'=>true],
    ['name' => 'Product6', 'img' => '/img/product-6.jpg', 'price' => 150,'discount'=>0.2,'rating'=>3,'rating_count'=>99,'is_featured'=>false,'is_recent'=>true],
    ['name' => 'Product2', 'img' => '/img/product-2.jpg', 'price' => 160,'discount'=>0.3,'rating'=>4,'rating_count'=>98,'is_featured'=>false,'is_recent'=>true],
    ['name' => 'Product1', 'img' => '/img/product-1.jpg', 'price' => 170,'discount'=>0.2,'rating'=>5,'rating_count'=>99,'is_featured'=>false,'is_recent'=>true],

    ['name' => 'Product1', 'img' => '/img/product-1.jpg', 'price' => 100,'discount'=>0.1,'rating'=>0,'rating_count'=>100,'is_featured'=>false,'is_recent'=>true],
    ['name' => 'Product2', 'img' => '/img/product-2.jpg', 'price' => 110,'discount'=>0.125,'rating'=>1,'rating_count'=>90,'is_featured'=>false,'is_recent'=>true],
    ['name' => 'Product3', 'img' => '/img/product-3.jpg', 'price' => 120,'discount'=>0.2,'rating'=>1.5,'rating_count'=>95,'is_featured'=>false,'is_recent'=>true],
    ['name' => 'Product4', 'img' => '/img/product-4.jpg', 'price' => 130,'discount'=>0.1,'rating'=>4.5,'rating_count'=>100,'is_featured'=>false,'is_recent'=>true],
    ['name' => 'Product5', 'img' => '/img/product-5.jpg', 'price' => 140,'discount'=>0.1,'rating'=>3.5,'rating_count'=>97,'is_featured'=>true,'is_recent'=>false],
    ['name' => 'Product6', 'img' => '/img/product-6.jpg', 'price' => 150,'discount'=>0.2,'rating'=>3,'rating_count'=>99,'is_featured'=>true,'is_recent'=>false],
    ['name' => 'Product2', 'img' => '/img/product-2.jpg', 'price' => 160,'discount'=>0.3,'rating'=>4,'rating_count'=>98,'is_featured'=>true,'is_recent'=>false],
    ['name' => 'Product1', 'img' => '/img/product-1.jpg', 'price' => 170,'discount'=>0.2,'rating'=>5,'rating_count'=>99,'is_featured'=>true,'is_recent'=>false],

];


$categories  = [
    ['name' => 'Clothes', 'img' => 'img/cat-1.jpg', 'num_of_product' => '100 Products'],
    ['name' => 'Elctronics', 'img' => 'img/cat-2.jpg', 'num_of_product' => '110 Products'],
    ['name' => 'Shoes', 'img' => 'img/cat-3.jpg', 'num_of_product' => '80 Products'],
    ['name' => 'Cosmetics', 'img' => 'img/cat-4.jpg', 'num_of_product' => '90 Products'],
    ['name' => 'Clothes', 'img' => 'img/cat-1.jpg', 'num_of_product' => '100 Products'],
    ['name' => 'Elctronics', 'img' => 'img/cat-2.jpg', 'num_of_product' => '110 Products'],
    ['name' => 'Shoes', 'img' => 'img/cat-3.jpg', 'num_of_product' => '80 Products'],
    ['name' => 'Cosmetics', 'img' => 'img/cat-4.jpg', 'num_of_product' => '90 Products'],
    ['name' => 'Clothes', 'img' => 'img/cat-1.jpg', 'num_of_product' => '100 Products'],
    ['name' => 'Elctronics', 'img' => 'img/cat-2.jpg', 'num_of_product' => '110 Products'],
    ['name' => 'Shoes', 'img' => 'img/cat-3.jpg', 'num_of_product' => '80 Products'],
    ['name' => 'Cosmetics', 'img' => 'img/cat-4.jpg', 'num_of_product' => '90 Products']
];
?>
